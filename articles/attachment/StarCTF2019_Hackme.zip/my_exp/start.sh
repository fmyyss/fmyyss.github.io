#!/bin/sh
name=$1

if [[ $name == "" ]];then
	name=exp.c
fi
gcc ${name} -o exp --static -pthread -masm=intel
cp ./exp ../tmp/home/pwn/
cd ../tmp
./fs.sh
cd ..
./startvm.sh
