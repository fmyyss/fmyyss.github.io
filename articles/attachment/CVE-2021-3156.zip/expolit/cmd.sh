b main
r
c
b *(main+1019)
c
b ./sudoers.c:847
b ./sudoers.c:872
b nss_load_library
c

